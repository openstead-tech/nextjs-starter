import Image from "next/image";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center bg-zinc-50 font-sans dark:bg-black">
      <main className="flex flex-1 w-full max-w-3xl flex-col items-center justify-between py-32 px-16 bg-white dark:bg-black sm:items-start">
        <a href="https://openstead.tech" aria-label="Openstead home" className="flex items-center gap-3 text-2xl font-semibold tracking-tight">
          <Image className="dark:invert" src="/openstead.svg" alt="" width={32} height={32} priority />
          <span>openstead</span>
        </a>
        <div className="flex flex-col items-center gap-6 text-center sm:items-start sm:text-left">
          <h1 className="max-w-xs text-3xl font-semibold leading-10 tracking-tight text-black dark:text-zinc-50">
            To get started, edit the page.tsx file.
          </h1>
          <p className="max-w-md text-lg leading-8 text-zinc-600 dark:text-zinc-400">
            Looking for a starting point or more instructions? Head over to{" "}
            <a
              href="https://dashboard.openstead.tech/new"
              className="font-medium text-zinc-950 dark:text-zinc-50"
            >
              Starter Projects
            </a>{" "}
            or the{" "}
            <a
              href="https://docs.openstead.tech"
              className="font-medium text-zinc-950 dark:text-zinc-50"
            >
              Documentation
            </a>{" "}
            center.
          </p>
        </div>
        <div className="flex flex-col gap-4 text-base font-medium sm:flex-row">
          <a
            className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-foreground px-5 text-background transition-colors hover:bg-[#383838] dark:hover:bg-[#ccc] md:w-[158px]"
            href="https://dashboard.openstead.tech"
            target="_blank"
            rel="noopener noreferrer"
          >
            Open dashboard
          </a>
          <a
            className="flex h-12 w-full items-center justify-center rounded-full border border-solid border-black/[.08] px-5 transition-colors hover:border-transparent hover:bg-black/[.04] dark:border-white/[.145] dark:hover:bg-[#1a1a1a] md:w-[158px]"
            href="https://docs.openstead.tech"
            target="_blank"
            rel="noopener noreferrer"
          >
            Documentation
          </a>
        </div>
      </main>
    </div>
  );
}
